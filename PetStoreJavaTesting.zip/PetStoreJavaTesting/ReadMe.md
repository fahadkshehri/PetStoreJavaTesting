## PetStore Java Testing using RestAssuredLibrary and TestNG Framework
